#!/bin/bash

usea=$(whoami)
hos=$(hostname)
dt=$(date "+%Y-%m-%d %H:%M:%S")
os=$(uname -s)
curr=$(pwd)
home=$HOME
usr=$(who | wc -l)
upp=$(uptime -p)
disk=$(df -h / | awk 'NR==2 {print $3 "/" $2}')
mem=$(free -h | awk 'NR==2 {print $3 "/" $2}')

echo "======================================="
echo "       System Information Display"
echo "======================================="
echo "Username         : $usea"
echo "Hostname         : $hos"
echo "date and time    : $dt"
echo "OS               : $os"
echo "Current Diectory : $curr"
echo "home directory   : $home"
echo "online user      : $usr"
echo "UP time          : $upp"
echo "Disk Usage       : $disk"
echo "Memory Usage     : $mem"
echo "======================================="

